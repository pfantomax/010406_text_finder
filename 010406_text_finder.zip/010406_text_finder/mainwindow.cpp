#include "mainwindow.h"
#include "./ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_searchButton_clicked()
{
    QString searchString = ui->lineEdit->text();
    QTextDocument *document = ui->textEdit->document();

    if (searchString.isEmpty() || document->isEmpty())
    {
        QMessageBox::information(this, tr(""), tr("Порожнє текстове поле, або поле пошуку.\nБудьласка введіть данні та натисніть кнопку пошуку."));
    }
    else
    {
        ui->textEdit->selectAll();
        ui->textEdit->setTextColor(QColor(Qt::black));

        QTextCursor cursor(document);
        QTextCharFormat plainFormat(cursor.charFormat());
        QTextCharFormat colorFormat = plainFormat;
        colorFormat.setForeground(Qt::red);

        int wordCount = 0;

        while (!cursor.isNull() && !cursor.atEnd())
        {
            cursor = document->find(searchString, cursor, QTextDocument::FindWholeWords);

            if (!cursor.isNull())
            {
                cursor.mergeCharFormat(colorFormat);
                cursor.movePosition(QTextCursor::WordRight, QTextCursor::KeepAnchor);
                wordCount++;
            }
        }

        // Виведення кількості знайдених слів
        ui->wordCountLabel->setText(QString("Знайдено слів: %1").arg(wordCount));
    }
}
